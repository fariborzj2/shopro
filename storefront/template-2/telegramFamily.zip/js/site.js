window.addEventListener("scroll", function () {
  if (window.scrollY >= 100) {
    document.querySelector(".top-menu").style.boxShadow = "0 10px 10px rgba(0,0,0,0.05)";
  } else {
    document.querySelector(".top-menu").style.boxShadow = "";
  }
});

document.querySelector(".open-menu").addEventListener("click", function () {
  this.classList.toggle("active");
  document.querySelector(".menu").classList.toggle("active");
  document.body.classList.toggle("no-scroll");
  document.body.classList.toggle("after-body");
});

document.body.addEventListener("click", function (e) {
  if (document.querySelector(".menu").classList.contains("active") &&
    !e.target.closest(".menu") &&
    !e.target.closest(".open-menu")
  ) {
    document.querySelector(".menu").classList.remove("active");
    document.querySelector(".open-menu").classList.remove("active");
    document.body.classList.remove("no-scroll");
    document.body.classList.remove("after-body");
  }
});

window.addEventListener('resize', function() {
  document.querySelector(".menu").classList.remove("active");
  document.querySelector(".open-menu").classList.remove("active");
  document.body.classList.remove("no-scroll");
  document.body.classList.remove("after-body");
});

$("[data-tab]").on("click", function () {
    const $this = $(this);
    const $container = $this.closest(".tab-container");
    const activeTab = $this.attr("data-tab");
    $this.addClass("active").siblings("[data-tab]").removeClass("active");
    $container
      .find(`#${activeTab}`)
      .addClass("active")
      .slideDown()
      .siblings(".tab-content")
      .removeClass("active")
      .slideUp();
  });

  $(".tab-container").each(function () {
    const $container = $(this);
    const $activeItem = $container.find("[data-tab].active");
    if ($activeItem.length) {
      const activeTab = $activeItem.attr("data-tab");
      $container
        .find(`#${activeTab}`)
        .addClass("active")
        .slideDown()
        .siblings(".tab-content")
        .removeClass("active")
        .slideUp();
    } else {
      const $firstItem = $container.find("[data-tab]:first-child");
      const firstTab = $firstItem.attr("data-tab");
      $firstItem.addClass("active");
      $container
        .find(`#${firstTab}`)
        .addClass("active")
        .slideDown()
        .siblings(".tab-content")
        .removeClass("active")
        .slideUp();
    }
  });

  $('.toggle-slide').on('click', function() {
    var $slideDown = $(this).next('.slide-down');
    
    if ($slideDown.is(':visible')) {
        $slideDown.slideUp();
    } else {
        $(this).closest('.toggle-slide-box').find('.slide-down').not($slideDown).slideUp();
        $slideDown.slideDown();
    }
  });

  $('[data-modal]').click(function() {
    var modalId = $(this).data('modal');
    $('#' + modalId).fadeIn().css({'display':'flex'}).find('.modal').css({'transform':'scale(1)'});
    $('body').addClass('no-scroll');
  });  

  $(".modal-close").on("click", function () {
    $(".modal-box").fadeOut(), $("body").removeClass("no-scroll");
    $(this).closest(".modal").css("transform", "scale(0.8)");
});

$(".modal-box").on("click", function (t) {
    $(t.target).closest(".modal").length || ($(".modal-box").fadeOut(), $("body").removeClass("no-scroll"), $(this).find(".modal").css("transform", "scale(0.8)"));
});

  // slider option

  var sliderOption = {
    slidesPerView: 4,
    spaceBetween: 20,
    resizeObserver: true,
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
    watchState: true,
    updateOnWindowResize: true,
    breakpointsBase: 'container',
    grabCursor: true,
    speed: 1500,
    breakpoints: {
      0: {
        slidesPerView: 1.1,
        spaceBetween: 20,
      },

      365: {
        slidesPerView: 1.4,
        spaceBetween: 20,
      },

      640: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
    },
  }

  var featureSlider = new Swiper(".feature-slider", {
    navigation: {
      nextEl: '.feature-next',
      prevEl: '.feature-prev',
    },
    ...sliderOption
    
  });

  var commentsSlider = new Swiper(".comments-slider", {
    navigation: {
      nextEl: '.comment-next',
      prevEl: '.comment-prev',
    },
    ...sliderOption
    
  });

  var blogSlider = new Swiper(".blog-slider", {
    navigation: {
      nextEl: '.blog-next',
      prevEl: '.blog-prev',
    },
    speed: 500,
    loop: true,
    autoplay: {
      delay: 2500,
      disableOnInteraction: false,
    },
    ...sliderOption
    
  });
 
  document.addEventListener("DOMContentLoaded", function() {
    // Initialize the initial height for all comment lists
    document.querySelectorAll(".hide-box").forEach(function(comentList) {
        var dataHeight = parseInt(comentList.getAttribute("data-height"), 10);
        comentList.style.maxHeight = dataHeight + "px";
    });

    document.querySelectorAll(".show-more").forEach(function(element) {
        element.addEventListener("click", function() {
            var comentList = this.closest(".show-btn-box").previousElementSibling;
            var dataHeight = parseInt(comentList.getAttribute("data-height"), 10);
            
            var isOpen = comentList.classList.toggle("open");
            var maxHeight = isOpen ? comentList.scrollHeight : dataHeight;
            var startHeight = isOpen ? dataHeight : comentList.scrollHeight;
            var startTime = null;
            var duration = 1000;

            function animateHeight(timestamp) {
                if (!startTime) startTime = timestamp;
                var elapsedTime = timestamp - startTime;
                var progress = Math.min(elapsedTime / duration, 1);
                var currentHeight = startHeight + (maxHeight - startHeight) * progress;
                comentList.style.maxHeight = currentHeight + "px";

                if (progress < 1) {
                    requestAnimationFrame(animateHeight);
                }
            }

            requestAnimationFrame(animateHeight);

            var toggleText = this.querySelector('.toggle-text');
            var icon = this.querySelector('.toggle-icon');

            if (isOpen) {
                toggleText.textContent = 'مشاهده کمتر';
                icon.classList.add('horizon-y');
            } else {
                toggleText.textContent = 'مشاهده بیشتر';
                icon.classList.remove('horizon-y');
            }

            
        });
    });
});
